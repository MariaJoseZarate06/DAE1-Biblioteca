package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Editorial {

    private Integer IdEditorial;
    private String NomEditorial;
    private String Pais;
    private Date AñoPubli;

}
