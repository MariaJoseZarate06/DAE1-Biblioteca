package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Autor {

    private Integer IdAutor;
    private String NomAutor;
    private String ApeAutor;
    private String Telefono;
    private String Ciudad;
    private String NomLibro;

}
