package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Empleado {

    private Integer IdEmpleado;
    private String NomEmpleado;
    private String ApeEmpleado;
    private Date FecNacimiento;
    private String Telefono;

}
