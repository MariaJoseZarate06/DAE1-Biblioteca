package pe.isil.dao;

import pe.isil.model.Cliente;
import pe.isil.model.Editorial;
import pe.isil.util.DatabasUtil;

import java.sql.*;
import java.util.List;

public class EditorialDAO {

    public static void create(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "INSERT INTO Editorial (NomEditorial, Pais, AñoPubli) values (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, editorial.getNomEditorial());
                statement.setString(2, editorial.getPais());
                statement.setDate(3, editorial.getAñoPubli();
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

    }

    public static void update(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "UPDATE Editorial SET Pais=?, AñoPubli=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, editorial.getPais());
                statement.setDate(2, (Date) editorial.getAñoPubli());
                statement.setInt(3, editorial.getIdEditorial());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static void delete(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "DELETE FROM Editorial  WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, editorial.getIdEditorial());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static List<Editorial> findAll() {
        List<Editorial> editoriales = new ArrayList<>();
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Editorial";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Editorial editorial = new Editorial(
                                resultSet.getInt("IdEditorial"),
                                resultSet.getString("NomEditorial"),
                                resultSet.getString("Pais"),
                                resultSet.getDate("AñoPubli")
                        );
                        editoriales.add(editorial);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return editoriales;
    }

    public static Editorial findById(Integer IdEditorial) {
        Editorial editorial = null;
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Editorial where id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, IdEditorial);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        editorial = new Editorial(
                                resultSet.getInt("IdEditorial"),
                                resultSet.getString("NomEditorial"),
                                resultSet.getString("Pais"),
                                resultSet.getDate("AñoPubli")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

        return editorial;
    }


}
