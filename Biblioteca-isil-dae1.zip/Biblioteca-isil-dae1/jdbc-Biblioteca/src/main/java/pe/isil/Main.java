package pe.isil;

import pe.isil.dao.AutorDAO;
import pe.isil.dao.ClienteDAO;
import pe.isil.dao.EditorialDAO;
import pe.isil.model.Autor;
import pe.isil.model.Cliente;
import pe.isil.model.Editorial;

public class Main {

    public static void main(String[] args){

        //CREATE
        Cliente cliente = new Cliente(33, "Mario", "Arana", "74820342", "m_arana@gmail.com", "968302853")
                ClienteDAO.create(cliente);

        //FIND ALL
        List<Cliente> clientes = ClienteDAO.findAll();
        System.out.println("clientes = " + clientes);

        //FIND BY ID
        Cliente cliente1 = ClienteDAO.findById(33);
        System.out.println("cliente1 = " + cliente1);

        //UPDATE
        Cliente cliente3 = ClienteDAO.update(33);
        System.out.println("cliente = " + cliente3);

        //DELETE
        Cliente cliente2 = ClienteDAO.delete(33);




        //CREATE
        Editorial editorial = new Editorial(21, "Aguilar", "Colombia", LocalDate.of(2019,11,11))
        EditorialDAO.create(editorial);

        //FIND ALL
        List<Editorial> editoriales = EditorialDAO.findAll();
        System.out.println("editoriales = " + editoriales);

        //FIND BY ID
        Editorial editorial1 = EditorialDAO.findById(21);
        System.out.println("editorial = " + editorial1);

        //UPDATE
        Editorial editorial2 = EditorialDAO.update(21);
        System.out.println("cliente = " + cliente3);

        //DELETE
        Editorial editorial3 = EditorialDAO.delete(21);



        //CREATE
        Autor autor = new Autor(12, "Mario", "Vargas Llosa", "956178092", "Lima, Peru", "La ciudad y los perros")
        EditorialDAO.create(autor);

        //FIND ALL
        List<Autor> autores = AutorDAO.findAll();
        System.out.println("autores = " + autores);

        //FIND BY ID
        Autor autor1 = AutorDAO.findById(12);
        System.out.println("autor = " + autor1);

        //UPDATE
        Autor autor2 = AutorDAO.update(12);
        System.out.println("autor = " + autor2);

        //DELETE
        Autor autor3 = AutorDAO.delete(12);


    }



}
