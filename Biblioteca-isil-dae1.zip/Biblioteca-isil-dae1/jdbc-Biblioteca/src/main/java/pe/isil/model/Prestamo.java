package pe.isil.model;

public class Prestamo {
}
