package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Libro {

    private Integer IdLibro;
    private String NomLibro;
    private String NomEditorial;
    private String NomAutor;
    private String Genero;
    private String NumPaginas;
    private Date AñoEdicion;

}
