package pe.isil.dao;

import pe.isil.model.Autor;
import pe.isil.model.Cliente;
import pe.isil.util.DatabasUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class AutorDAO {

    public static void create(Autor autor) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "INSERT INTO Autor (NomAutor, ApeAutor, Telefono, Ciudad, NomLibro) values (?, ?, ?, ?, ?) ";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, autor.getNomAutor());
                statement.setString(2, autor.getApeAutor());
                statement.setString(3, autor.getTelefono());
                statement.setString(4, autor.getCiudad());
                statement.setString(5, autor.getNomLibro());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

    }

    public static void update(Autor autor) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "UPDATE Autor SET Telefono=?, Ciudad=? WHERE IdAutor=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, autor.getTelefono());
                statement.setString(2, autor.getCiudad());
                statement.setInt(3, autor.getIdAutor());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static void delete(Autor autor) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "DELETE FROM Autor  WHERE IdAutor=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, autor.getIdAutor());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static List<Autor> findAll() {
        List<Autor> autores = new ArrayList<>();
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Autor";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Autor autor = new Autor(
                                resultSet.getInt("IdAutor"),
                                resultSet.getString("NomAutor"),
                                resultSet.getString("ApeAutor"),
                                resultSet.getString("Telefono"),
                                resultSet.getString("Ciudad"),
                                resultSet.getString("NomLibro")
                        );
                        autores.add(autor);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return autores;
    }

    public static Autor findById(Integer IdAutor) {
        Autor autor = null;
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Autor where id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, IdAutor);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        autor = new Autor(
                                resultSet.getInt("IdAutor"),
                                resultSet.getString("NomAutor"),
                                resultSet.getString("ApeAutor"),
                                resultSet.getString("Telefono"),
                                resultSet.getString("Ciudad"),
                                resultSet.getString("NomLibro")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

        return autor;
    }




}
